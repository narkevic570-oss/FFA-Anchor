package dev.ffa;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Biome;
import org.bukkit.generator.BiomeProvider;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.generator.WorldInfo;
import org.bukkit.util.noise.SimplexOctaveGenerator;

import java.util.List;
import java.util.Random;

/** Плоский мир с мини-холмами: без деревьев, пещер, структур и мобов. */
public class HillsGenerator extends ChunkGenerator {

    private static final int BASE = 64;
    private static final int AMPLITUDE = 5;   // высота холмов (блоки)
    private static final double SCALE = 1.0 / 40.0; // ширина холмов

    private final SimplexOctaveGenerator noise;

    public HillsGenerator(long seed) {
        noise = new SimplexOctaveGenerator(seed, 3);
        noise.setScale(SCALE);
    }

    private int height(int x, int z) {
        double n = noise.noise(x, z, 0.5, 0.5);
        int h = BASE + (int) Math.round(n * AMPLITUDE);
        return Math.max(58, Math.min(72, h));
    }

    @Override
    public void generateNoise(WorldInfo info, Random random, int chunkX, int chunkZ, ChunkData chunk) {
        int minY = info.getMinHeight();
        chunk.setRegion(0, minY, 0, 16, minY + 1, 16, Material.BEDROCK);
        chunk.setRegion(0, minY + 1, 0, 16, 55, 16, Material.STONE);
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                int h = height(chunkX * 16 + x, chunkZ * 16 + z);
                for (int y = 55; y < h; y++) {
                    chunk.setBlock(x, y, z, Material.DIRT);
                }
                chunk.setBlock(x, h, z, Material.GRASS_BLOCK);
            }
        }
    }

    @Override
    public BiomeProvider getDefaultBiomeProvider(WorldInfo info) {
        return new BiomeProvider() {
            @Override
            public Biome getBiome(WorldInfo worldInfo, int x, int y, int z) {
                return Biome.PLAINS;
            }

            @Override
            public List<Biome> getBiomes(WorldInfo worldInfo) {
                return List.of(Biome.PLAINS);
            }
        };
    }

    @Override
    public Location getFixedSpawnLocation(World world, Random random) {
        return new Location(world, 0.5, height(0, 0) + 1, 0.5);
    }
}
