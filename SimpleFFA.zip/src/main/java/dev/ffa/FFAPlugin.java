package dev.ffa;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.ScoreboardManager;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

public class FFAPlugin extends JavaPlugin implements Listener {

    private static final int MAX_TRACKED = 200_000;
    private static final String PFX = ChatColor.GOLD + "[FFA] " + ChatColor.RESET;
    private static final List<String> PUBLIC_SUBS = List.of("stats", "top", "help");
    private static final List<String> ADMIN_SUBS = List.of("setkit", "kit", "addspawn", "delspawn",
            "spawns", "radius", "createworld", "world", "reset", "reload", "info");

    // статистика: [убийства, смерти, серия, рекорд серии]
    private final Map<UUID, int[]> stats = new HashMap<>();
    private final Map<UUID, String> names = new HashMap<>();
    private final Map<Location, BlockState> changed = new LinkedHashMap<>();
    private final List<String> spawnRaw = new ArrayList<>();
    private final List<Location> spawnLocs = new ArrayList<>();
    private final Set<String> arenaWorlds = new HashSet<>();
    private final Random random = new Random();

    private File dataFile;
    private YamlConfiguration data;
    private ItemStack[] kitStorage;
    private ItemStack[] kitArmor;
    private ItemStack kitOffhand;
    private double radius = 10;
    private boolean dirty;
    private boolean resetting;
    private long nextReset;
    private boolean warned30;
    private boolean warned10;

    // ================================================================ lifecycle

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadData();
        getServer().getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTask(this, () -> {
            loadWorlds();
            rebuildSpawns();
            resetTimer();
            startTasks();
        });
        getLogger().info("SimpleFFA enabled");
    }

    @Override
    public void onDisable() {
        saveData();
    }

    private void startTasks() {
        int[] tick = {0};
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            tick[0]++;
            int interval = getConfig().getInt("reset-interval-minutes", 10);
            if (interval > 0 && !resetting) {
                long left = (nextReset - System.currentTimeMillis()) / 1000L;
                if (left <= 0) {
                    resetArena(null);
                } else if (left <= 10 && !warned10) {
                    warned10 = true;
                    warned30 = true;
                    if (!changed.isEmpty()) {
                        Bukkit.broadcastMessage(PFX + ChatColor.YELLOW + "Арена обновится через 10 секунд!");
                    }
                } else if (left <= 30 && !warned30) {
                    warned30 = true;
                    if (!changed.isEmpty()) {
                        Bukkit.broadcastMessage(PFX + ChatColor.YELLOW + "Арена обновится через 30 секунд.");
                    }
                }
            }
            if (tick[0] % 60 == 0) maintainWorlds();
            if (tick[0] % 30 == 0 && dirty) saveData();
        }, 20L, 20L);
    }

    private void maintainWorlds() {
        if (!getConfig().getBoolean("lock-day", true)) return;
        for (String name : arenaWorlds) {
            World w = Bukkit.getWorld(name);
            if (w == null) continue;
            w.setTime(6000L);
            w.setStorm(false);
            w.setThundering(false);
        }
    }

    // ================================================================ data

    private void loadData() {
        getDataFolder().mkdirs();
        dataFile = new File(getDataFolder(), "arena.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);

        spawnRaw.clear();
        spawnRaw.addAll(data.getStringList("spawns"));
        radius = data.contains("radius") ? data.getDouble("radius") : getConfig().getDouble("spawn-radius", 10.0);
        kitStorage = readItems("kit.storage");
        kitArmor = readItems("kit.armor");
        kitOffhand = data.getItemStack("kit.offhand");

        stats.clear();
        names.clear();
        ConfigurationSection s = data.getConfigurationSection("stats");
        if (s != null) {
            for (String key : s.getKeys(false)) {
                try {
                    UUID id = UUID.fromString(key);
                    stats.put(id, new int[]{s.getInt(key + ".kills"), s.getInt(key + ".deaths"),
                            0, s.getInt(key + ".best")});
                    String n = s.getString(key + ".name");
                    if (n != null) names.put(id, n);
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
    }

    private void saveData() {
        data.set("spawns", spawnRaw);
        data.set("radius", radius);
        data.set("kit.storage", kitStorage == null ? null : Arrays.asList(kitStorage));
        data.set("kit.armor", kitArmor == null ? null : Arrays.asList(kitArmor));
        data.set("kit.offhand", kitOffhand);
        for (Map.Entry<UUID, int[]> e : stats.entrySet()) {
            String base = "stats." + e.getKey();
            data.set(base + ".kills", e.getValue()[0]);
            data.set(base + ".deaths", e.getValue()[1]);
            data.set(base + ".best", e.getValue()[3]);
            String n = names.get(e.getKey());
            if (n != null) data.set(base + ".name", n);
        }
        try {
            data.save(dataFile);
            dirty = false;
        } catch (IOException ex) {
            getLogger().warning("Не удалось сохранить arena.yml: " + ex.getMessage());
        }
    }

    private ItemStack[] readItems(String path) {
        List<?> list = data.getList(path);
        if (list == null) return null;
        ItemStack[] arr = new ItemStack[list.size()];
        for (int i = 0; i < arr.length; i++) {
            if (list.get(i) instanceof ItemStack it) arr[i] = it;
        }
        return arr;
    }

    private ItemStack[] cloneAll(ItemStack[] src) {
        ItemStack[] out = new ItemStack[src.length];
        for (int i = 0; i < src.length; i++) {
            out[i] = (src[i] == null || src[i].getType().isAir()) ? null : src[i].clone();
        }
        return out;
    }

    // ================================================================ worlds & spawns

    private void loadWorlds() {
        ConfigurationSection s = data.getConfigurationSection("worlds");
        if (s == null) return;
        for (String name : s.getKeys(false)) {
            arenaWorlds.add(name);
            if (Bukkit.getWorld(name) == null) buildWorld(name, s.getLong(name));
        }
    }

    private World buildWorld(String name, long seed) {
        try {
            WorldCreator wc = new WorldCreator(name);
            wc.environment(World.Environment.NORMAL);
            wc.generator(new HillsGenerator(seed));
            wc.seed(seed);
            wc.generateStructures(false);
            World w = Bukkit.createWorld(wc);
            if (w != null) {
                w.setTime(6000L);
                w.setStorm(false);
            }
            return w;
        } catch (Exception ex) {
            getLogger().warning("Не удалось создать мир " + name + ": " + ex.getMessage());
            return null;
        }
    }

    private String ser(Location l) {
        return l.getWorld().getName() + ";" + l.getX() + ";" + l.getY() + ";" + l.getZ()
                + ";" + l.getYaw() + ";" + l.getPitch();
    }

    private Location de(String s) {
        try {
            String[] p = s.split(";");
            World w = Bukkit.getWorld(p[0]);
            if (w == null) return null;
            return new Location(w, Double.parseDouble(p[1]), Double.parseDouble(p[2]),
                    Double.parseDouble(p[3]), Float.parseFloat(p[4]), Float.parseFloat(p[5]));
        } catch (Exception e) {
            return null;
        }
    }

    private void rebuildSpawns() {
        spawnLocs.clear();
        for (String raw : spawnRaw) {
            String[] p = raw.split(";");
            if (p.length > 0) arenaWorlds.add(p[0]);
            Location l = de(raw);
            if (l != null) spawnLocs.add(l);
        }
    }

    private boolean active() {
        return !spawnLocs.isEmpty();
    }

    private boolean isArenaWorld(World w) {
        return w != null && arenaWorlds.contains(w.getName());
    }

    private boolean inZone(Location l) {
        World w = l.getWorld();
        if (w == null) return false;
        double r2 = radius * radius;
        for (Location sp : spawnLocs) {
            if (!w.equals(sp.getWorld())) continue;
            double dx = l.getX() - sp.getX();
            double dz = l.getZ() - sp.getZ();
            if (dx * dx + dz * dz <= r2 && Math.abs(l.getY() - sp.getY()) <= radius) return true;
        }
        return false;
    }

    private Location pickSpawn(Player who) {
        if (spawnLocs.isEmpty()) return null;
        if (!getConfig().getBoolean("smart-spawn", true) || spawnLocs.size() == 1) {
            return spawnLocs.get(random.nextInt(spawnLocs.size()));
        }
        List<Location> safe = new ArrayList<>();
        Location best = null;
        double bestDist = -1;
        for (Location sp : spawnLocs) {
            double min = Double.MAX_VALUE;
            for (Player o : sp.getWorld().getPlayers()) {
                if (o.equals(who) || o.isDead() || o.getGameMode() == GameMode.SPECTATOR) continue;
                min = Math.min(min, o.getLocation().distanceSquared(sp));
            }
            if (min >= 400) safe.add(sp);
            if (min > bestDist) {
                bestDist = min;
                best = sp;
            }
        }
        return safe.isEmpty() ? best : safe.get(random.nextInt(safe.size()));
    }

    // ================================================================ players & kit

    private boolean isBuilder(Player p) {
        return p.hasPermission("ffa.admin") && p.getGameMode() == GameMode.CREATIVE;
    }

    private boolean hasKit() {
        return kitStorage != null || kitArmor != null || kitOffhand != null;
    }

    private void resetPlayer(Player p) {
        PlayerInventory inv = p.getInventory();
        inv.clear();
        inv.setArmorContents(new ItemStack[4]);
        inv.setItemInOffHand(new ItemStack(Material.AIR));
        for (PotionEffect e : new ArrayList<>(p.getActivePotionEffects())) {
            p.removePotionEffect(e.getType());
        }
        p.setHealth(20.0);
        p.setFoodLevel(20);
        p.setSaturation(20f);
        p.setFireTicks(0);
        p.setFallDistance(0f);
    }

    private void giveKit(Player p) {
        if (!hasKit()) return;
        resetPlayer(p);
        PlayerInventory inv = p.getInventory();
        if (kitStorage != null) inv.setStorageContents(cloneAll(kitStorage));
        if (kitArmor != null) inv.setArmorContents(cloneAll(kitArmor));
        if (kitOffhand != null) inv.setItemInOffHand(kitOffhand.clone());
    }

    private int[] statsOf(Player p) {
        names.put(p.getUniqueId(), p.getName());
        return stats.computeIfAbsent(p.getUniqueId(), k -> new int[4]);
    }

    private String kd(int[] s) {
        double v = s[1] == 0 ? (double) s[0] : s[0] / (double) s[1];
        return String.format(Locale.US, "%.2f", v);
    }

    private void updateBoard(Player p) {
        if (!getConfig().getBoolean("scoreboard", true)) return;
        ScoreboardManager m = Bukkit.getScoreboardManager();
        if (m == null) return;
        int[] s = statsOf(p);
        Scoreboard sb = m.getNewScoreboard();
        Objective o = sb.registerNewObjective("ffa", Criteria.DUMMY,
                ChatColor.GOLD + "" + ChatColor.BOLD + "FFA");
        o.setDisplaySlot(DisplaySlot.SIDEBAR);
        String[] lines = {
                ChatColor.GREEN + "Убийства: " + ChatColor.WHITE + s[0],
                ChatColor.RED + "Смерти: " + ChatColor.WHITE + s[1],
                ChatColor.YELLOW + "K/D: " + ChatColor.WHITE + kd(s),
                ChatColor.AQUA + "Серия: " + ChatColor.WHITE + s[2],
                ChatColor.LIGHT_PURPLE + "Рекорд: " + ChatColor.WHITE + s[3]
        };
        for (int i = 0; i < lines.length; i++) {
            o.getScore(lines[i]).setScore(lines.length - i);
        }
        p.setScoreboard(sb);
    }

    // ================================================================ arena reset

    private void resetTimer() {
        int interval = getConfig().getInt("reset-interval-minutes", 10);
        nextReset = System.currentTimeMillis() + Math.max(1, interval) * 60_000L;
        warned30 = false;
        warned10 = false;
    }

    private void record(BlockState st) {
        if (changed.size() >= MAX_TRACKED) return;
        changed.putIfAbsent(st.getLocation(), st);
    }

    private void resetArena(CommandSender who) {
        resetTimer();
        for (String wn : arenaWorlds) {
            World w = Bukkit.getWorld(wn);
            if (w == null) continue;
            for (Item it : w.getEntitiesByClass(Item.class)) it.remove();
        }
        if (changed.isEmpty()) {
            if (who != null) who.sendMessage(PFX + "Нечего восстанавливать.");
            return;
        }
        List<BlockState> list = new ArrayList<>(changed.values());
        changed.clear();
        resetting = true;
        final int total = list.size();
        new BukkitRunnable() {
            int i = 0;

            @Override
            public void run() {
                int end = Math.min(i + 3000, list.size());
                for (; i < end; i++) {
                    try {
                        list.get(i).update(true, false);
                    } catch (Exception ignored) {
                    }
                }
                if (i >= list.size()) {
                    cancel();
                    resetting = false;
                    Bukkit.broadcastMessage(PFX + ChatColor.GREEN + "Арена обновлена! Блоков восстановлено: " + total);
                }
            }
        }.runTaskTimer(this, 0L, 1L);
    }

    // ================================================================ commands

    private Player needPlayer(CommandSender s) {
        if (s instanceof Player p) return p;
        s.sendMessage(PFX + "Эту команду можно только из игры.");
        return null;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String sub = args.length == 0 ? "help" : args[0].toLowerCase(Locale.ROOT);
        boolean admin = sender.hasPermission("ffa.admin");
        if (!PUBLIC_SUBS.contains(sub) && !admin) {
            sender.sendMessage(PFX + ChatColor.RED + "Нет прав.");
            return true;
        }
        switch (sub) {
            case "stats" -> cmdStats(sender, args);
            case "top" -> cmdTop(sender);
            case "setkit" -> {
                Player p = needPlayer(sender);
                if (p != null) {
                    PlayerInventory inv = p.getInventory();
                    kitStorage = cloneAll(inv.getStorageContents());
                    kitArmor = cloneAll(inv.getArmorContents());
                    ItemStack off = inv.getItemInOffHand();
                    kitOffhand = off.getType().isAir() ? null : off.clone();
                    saveData();
                    p.sendMessage(PFX + ChatColor.GREEN + "Кит сохранён (инвентарь, броня, левая рука). "
                            + "Теперь его получают все при входе и респавне.");
                }
            }
            case "kit" -> {
                Player p = needPlayer(sender);
                if (p != null) {
                    if (!hasKit()) {
                        p.sendMessage(PFX + ChatColor.RED + "Кит ещё не создан: /ffa setkit");
                    } else {
                        giveKit(p);
                        p.sendMessage(PFX + ChatColor.GREEN + "Кит выдан.");
                    }
                }
            }
            case "addspawn" -> {
                Player p = needPlayer(sender);
                if (p != null) {
                    spawnRaw.add(ser(p.getLocation()));
                    rebuildSpawns();
                    saveData();
                    p.sendMessage(PFX + ChatColor.GREEN + "Точка спавна #" + spawnRaw.size()
                            + " добавлена. Радиус защиты: " + radius);
                }
            }
            case "delspawn" -> {
                int n = args.length > 1 ? parseInt(args[1]) : -1;
                if (n < 1 || n > spawnRaw.size()) {
                    sender.sendMessage(PFX + ChatColor.RED + "Использование: /ffa delspawn <номер> (список: /ffa spawns)");
                } else {
                    spawnRaw.remove(n - 1);
                    rebuildSpawns();
                    saveData();
                    sender.sendMessage(PFX + ChatColor.YELLOW + "Точка #" + n + " удалена.");
                }
            }
            case "spawns" -> {
                if (spawnRaw.isEmpty()) {
                    sender.sendMessage(PFX + "Точек спавна нет. Встань на место и введи /ffa addspawn");
                }
                for (int i = 0; i < spawnRaw.size(); i++) {
                    String[] p = spawnRaw.get(i).split(";");
                    String text = p.length >= 4
                            ? p[0] + " " + (int) parseD(p[1]) + " " + (int) parseD(p[2]) + " " + (int) parseD(p[3])
                            : spawnRaw.get(i);
                    sender.sendMessage(ChatColor.YELLOW + "" + (i + 1) + ". " + ChatColor.WHITE + text);
                }
            }
            case "radius" -> {
                double r = args.length > 1 ? parseD(args[1]) : -1;
                if (r < 1 || r > 200) {
                    sender.sendMessage(PFX + ChatColor.RED + "Использование: /ffa radius <1-200>. Сейчас: " + radius);
                } else {
                    radius = r;
                    saveData();
                    sender.sendMessage(PFX + ChatColor.GREEN + "Радиус защиты спавна: " + radius);
                }
            }
            case "createworld" -> {
                Player p = needPlayer(sender);
                if (p != null) cmdCreateWorld(p, args);
            }
            case "world" -> {
                Player p = needPlayer(sender);
                if (p != null) {
                    World w = args.length > 1 ? Bukkit.getWorld(args[1]) : null;
                    if (w == null) {
                        p.sendMessage(PFX + ChatColor.RED + "Использование: /ffa world <название мира>");
                    } else {
                        p.teleport(w.getSpawnLocation());
                    }
                }
            }
            case "reset" -> resetArena(sender);
            case "reload" -> {
                saveData();
                reloadConfig();
                loadData();
                rebuildSpawns();
                resetTimer();
                sender.sendMessage(PFX + ChatColor.GREEN + "Конфиг перезагружен.");
            }
            case "info" -> {
                long left = Math.max(0, (nextReset - System.currentTimeMillis()) / 1000L);
                sender.sendMessage(PFX + "Точек спавна: " + spawnLocs.size() + "/" + spawnRaw.size()
                        + ", радиус: " + radius + ", кит: " + (hasKit() ? "есть" : "нет")
                        + ", изменённых блоков: " + changed.size()
                        + ", до обновления арены: " + left + " сек");
            }
            default -> cmdHelp(sender, admin);
        }
        return true;
    }

    private void cmdHelp(CommandSender s, boolean admin) {
        s.sendMessage(ChatColor.GOLD + "=== FFA ===");
        s.sendMessage(ChatColor.YELLOW + "/ffa stats [ник]" + ChatColor.GRAY + " - статистика");
        s.sendMessage(ChatColor.YELLOW + "/ffa top" + ChatColor.GRAY + " - топ по убийствам");
        if (!admin) return;
        s.sendMessage(ChatColor.YELLOW + "/ffa setkit" + ChatColor.GRAY + " - кит из твоего инвентаря");
        s.sendMessage(ChatColor.YELLOW + "/ffa kit" + ChatColor.GRAY + " - выдать кит себе");
        s.sendMessage(ChatColor.YELLOW + "/ffa addspawn" + ChatColor.GRAY + " - точка спавна здесь");
        s.sendMessage(ChatColor.YELLOW + "/ffa spawns, /ffa delspawn <№>");
        s.sendMessage(ChatColor.YELLOW + "/ffa radius <n>" + ChatColor.GRAY + " - радиус защиты спавна");
        s.sendMessage(ChatColor.YELLOW + "/ffa createworld <имя>" + ChatColor.GRAY + " - мир с мини-холмами");
        s.sendMessage(ChatColor.YELLOW + "/ffa world <имя>" + ChatColor.GRAY + " - телепорт в мир");
        s.sendMessage(ChatColor.YELLOW + "/ffa reset" + ChatColor.GRAY + " - обновить арену сейчас");
        s.sendMessage(ChatColor.YELLOW + "/ffa reload, /ffa info");
        s.sendMessage(ChatColor.GRAY + "Строить/тестировать: режим творчества. Играть с китом: выживание.");
    }

    private int parseInt(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private double parseD(String s) {
        try {
            return Double.parseDouble(s);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private void cmdCreateWorld(Player p, String[] args) {
        if (args.length < 2) {
            p.sendMessage(PFX + ChatColor.RED + "Использование: /ffa createworld <имя> (латиница, цифры, _ -)");
            return;
        }
        String name = args[1];
        if (!name.matches("[A-Za-z0-9_-]+")) {
            p.sendMessage(PFX + ChatColor.RED + "Имя: только латиница, цифры, _ и -");
            return;
        }
        if (Bukkit.getWorld(name) != null) {
            p.sendMessage(PFX + ChatColor.RED + "Мир с таким именем уже есть.");
            return;
        }
        long seed = random.nextLong();
        p.sendMessage(PFX + "Создаю мир " + name + "... подожди несколько секунд.");
        World w = buildWorld(name, seed);
        if (w == null) {
            p.sendMessage(PFX + ChatColor.RED + "Не удалось создать мир (смотри консоль сервера).");
            return;
        }
        data.set("worlds." + name, seed);
        arenaWorlds.add(name);
        saveData();
        p.teleport(w.getSpawnLocation());
        p.sendMessage(PFX + ChatColor.GREEN + "Мир создан. Теперь расставь точки: /ffa addspawn");
    }

    private void cmdStats(CommandSender sender, String[] args) {
        UUID id = null;
        String name = null;
        if (args.length > 1) {
            for (Map.Entry<UUID, String> en : names.entrySet()) {
                if (en.getValue().equalsIgnoreCase(args[1])) {
                    id = en.getKey();
                    name = en.getValue();
                }
            }
            if (id == null) {
                sender.sendMessage(PFX + ChatColor.RED + "Игрок не найден в статистике.");
                return;
            }
        } else if (sender instanceof Player p) {
            id = p.getUniqueId();
            name = p.getName();
        } else {
            sender.sendMessage(PFX + "Укажи ник: /ffa stats <ник>");
            return;
        }
        int[] s = stats.getOrDefault(id, new int[4]);
        sender.sendMessage(ChatColor.GOLD + "Статистика " + name + ": " + ChatColor.GREEN + "убийств " + s[0]
                + ChatColor.GRAY + ", " + ChatColor.RED + "смертей " + s[1]
                + ChatColor.GRAY + ", " + ChatColor.YELLOW + "K/D " + kd(s)
                + ChatColor.GRAY + ", " + ChatColor.AQUA + "серия " + s[2]
                + ChatColor.GRAY + ", " + ChatColor.LIGHT_PURPLE + "рекорд " + s[3]);
    }

    private void cmdTop(CommandSender sender) {
        List<Map.Entry<UUID, int[]>> list = new ArrayList<>(stats.entrySet());
        list.sort((a, b) -> Integer.compare(b.getValue()[0], a.getValue()[0]));
        sender.sendMessage(ChatColor.GOLD + "Топ FFA по убийствам:");
        int n = Math.min(10, list.size());
        if (n == 0) {
            sender.sendMessage(ChatColor.GRAY + "Пока никого.");
            return;
        }
        for (int i = 0; i < n; i++) {
            Map.Entry<UUID, int[]> en = list.get(i);
            String nm = names.getOrDefault(en.getKey(), "?");
            int[] s = en.getValue();
            sender.sendMessage(ChatColor.YELLOW + "" + (i + 1) + ". " + ChatColor.WHITE + nm
                    + ChatColor.GRAY + " - " + ChatColor.GREEN + s[0] + " уб." + ChatColor.GRAY
                    + " / " + ChatColor.RED + s[1] + " см." + ChatColor.GRAY + " (K/D " + kd(s) + ")");
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        boolean admin = sender.hasPermission("ffa.admin");
        if (args.length == 1) {
            List<String> all = new ArrayList<>(PUBLIC_SUBS);
            if (admin) all.addAll(ADMIN_SUBS);
            for (String s : all) {
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
            }
        } else if (args.length == 2 && admin && args[0].equalsIgnoreCase("world")) {
            for (World w : Bukkit.getWorlds()) {
                if (w.getName().toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) {
                    out.add(w.getName());
                }
            }
        }
        return out;
    }

    // ================================================================ events: players

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        names.put(p.getUniqueId(), p.getName());
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!p.isOnline()) return;
            if (active() && !isBuilder(p)) {
                Location s = pickSpawn(p);
                if (s != null) p.teleport(s);
                giveKit(p);
            }
            updateBoard(p);
        }, 2L);
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        if (!active() || !isArenaWorld(victim.getWorld())) return;

        e.getDrops().clear();
        e.setDroppedExp(0);

        int[] vs = statsOf(victim);
        vs[1]++;
        vs[2] = 0;

        Player killer = victim.getKiller();
        if (killer != null && !killer.equals(victim)) {
            int[] ks = statsOf(killer);
            ks[0]++;
            ks[2]++;
            if (ks[2] > ks[3]) ks[3] = ks[2];
            if (getConfig().getBoolean("heal-on-kill", true)) {
                killer.setHealth(20.0);
                killer.setFoodLevel(20);
            }
            e.setDeathMessage(ChatColor.RED + killer.getName() + ChatColor.GRAY + " убил "
                    + ChatColor.RED + victim.getName() + ChatColor.GRAY + " (серия: "
                    + ChatColor.YELLOW + ks[2] + ChatColor.GRAY + ")");
            updateBoard(killer);
        } else {
            e.setDeathMessage(ChatColor.RED + victim.getName() + ChatColor.GRAY + " погиб");
        }
        dirty = true;

        if (getConfig().getBoolean("immediate-respawn", true)) {
            Bukkit.getScheduler().runTask(this, () -> {
                if (victim.isOnline() && victim.isDead()) victim.spigot().respawn();
            });
        }
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        if (!active()) return;
        Location s = pickSpawn(p);
        if (s != null) e.setRespawnLocation(s);
        Bukkit.getScheduler().runTask(this, () -> {
            if (!p.isOnline()) return;
            if (!isBuilder(p)) giveKit(p);
            updateBoard(p);
        });
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        Player p = e.getPlayer();
        if (!getConfig().getBoolean("block-item-drop", true)) return;
        if (isArenaWorld(p.getWorld()) && !isBuilder(p)) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onFood(FoodLevelChangeEvent e) {
        if (!getConfig().getBoolean("no-hunger", true)) return;
        if (e.getEntity() instanceof Player p && isArenaWorld(p.getWorld()) && !isBuilder(p)) {
            e.setCancelled(true);
        }
    }

    // ================================================================ events: damage & protection

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (!isArenaWorld(p.getWorld())) return;
        if (e.getCause() == EntityDamageEvent.DamageCause.VOID) return;
        if (inZone(p.getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        Player attacker = null;
        if (e.getDamager() instanceof Player a) {
            attacker = a;
        } else if (e.getDamager() instanceof Projectile pr && pr.getShooter() instanceof Player b) {
            attacker = b;
        }
        if (attacker == null || !isArenaWorld(victim.getWorld())) return;
        if (inZone(attacker.getLocation()) || inZone(victim.getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        Block b = e.getBlock();
        if (!isArenaWorld(b.getWorld()) || isBuilder(p)) return;
        if (!canChange(b)) {
            e.setCancelled(true);
            return;
        }
        record(b.getState());
        e.setDropItems(false);
        e.setExpToDrop(0);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        Block b = e.getBlock();
        if (!isArenaWorld(b.getWorld()) || isBuilder(p)) return;
        if (!canChange(b)) {
            e.setCancelled(true);
            return;
        }
        record(e.getBlockReplacedState());
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent e) {
        handleBucket(e);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent e) {
        handleBucket(e);
    }

    private void handleBucket(PlayerBucketEvent e) {
        Block b = e.getBlock();
        if (!isArenaWorld(b.getWorld()) || isBuilder(e.getPlayer())) return;
        if (!canChange(b)) {
            e.setCancelled(true);
            return;
        }
        record(b.getState());
    }

    private boolean canChange(Block b) {
        if (resetting) return false;
        if (!getConfig().getBoolean("allow-building", true)) return false;
        return !inZone(b.getLocation());
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent e) {
        World w = e.getLocation().getWorld();
        if (!isArenaWorld(w)) return;
        e.setYield(0f);
        filterExplosion(e.blockList());
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        if (!isArenaWorld(e.getBlock().getWorld())) return;
        e.setYield(0f);
        filterExplosion(e.blockList());
    }

    private void filterExplosion(List<Block> blocks) {
        boolean destroy = getConfig().getBoolean("allow-explosion-damage", true)
                && getConfig().getBoolean("allow-building", true) && !resetting;
        Iterator<Block> it = blocks.iterator();
        while (it.hasNext()) {
            Block b = it.next();
            if (!destroy || inZone(b.getLocation())) {
                it.remove();
            } else {
                record(b.getState());
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBurn(BlockBurnEvent e) {
        Block b = e.getBlock();
        if (!isArenaWorld(b.getWorld())) return;
        if (!canChange(b)) {
            e.setCancelled(true);
            return;
        }
        record(b.getState());
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onIgnite(BlockIgniteEvent e) {
        Block b = e.getBlock();
        if (isArenaWorld(b.getWorld()) && inZone(b.getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFlow(BlockFromToEvent e) {
        Block to = e.getToBlock();
        if (!isArenaWorld(to.getWorld())) return;
        if (inZone(to.getLocation()) && !inZone(e.getBlock().getLocation())) e.setCancelled(true);
    }

    // ================================================================ events: world

    @EventHandler(ignoreCancelled = true)
    public void onCreatureSpawn(CreatureSpawnEvent e) {
        if (!getConfig().getBoolean("no-mobs", true)) return;
        if (!isArenaWorld(e.getLocation().getWorld())) return;
        SpawnReason r = e.getSpawnReason();
        if (r == SpawnReason.CUSTOM || r == SpawnReason.COMMAND
                || r == SpawnReason.SPAWNER_EGG || r == SpawnReason.DISPENSE_EGG) return;
        e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onWeather(WeatherChangeEvent e) {
        if (!getConfig().getBoolean("lock-day", true)) return;
        if (isArenaWorld(e.getWorld()) && e.toWeatherState()) e.setCancelled(true);
    }
}
